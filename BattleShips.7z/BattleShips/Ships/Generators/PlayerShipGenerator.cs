﻿// Copyright (c) 2021 Medtronic, Inc. All rights reserved.

namespace BattleShips.Misc
{
    public class PlayerShipGenerator : AbstractShipGenerator
    {
    }
}