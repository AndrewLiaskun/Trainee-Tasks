﻿// Copyright (c) 2021 Medtronic, Inc. All rights reserved.

namespace BattleShips.Misc
{
    public class ParamOfThePlayerBoard
    {
        public const int MinHight = 13;

        public const int MaxHight = 4;

        public const int MinWidth = 3;

        public const int MaxWidth = 21;
    }
}