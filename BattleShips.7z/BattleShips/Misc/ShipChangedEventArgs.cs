﻿// Copyright (c) 2021 Medtronic, Inc. All rights reserved.

using System;

namespace BattleShips.Misc
{
    public class ShipChangedEventArgs : EventArgs
    {
    }
}