﻿// Copyright (c) 2021 Medtronic, Inc. All rights reserved.

namespace BattleShips.Enums
{
    public enum PlayerType : byte
    {
        Unknown,

        User,

        Computer
    }
}