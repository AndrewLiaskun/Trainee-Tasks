﻿// Copyright (c) 2021 Medtronic, Inc. All rights reserved.

namespace BattleShips.Misc
{
    public class ParamOfTheEnemyBoard
    {
        public const int MinHight = 13;

        public const int MaxHight = 4;

        public const int MinWidth = 34;

        public const int MaxWidth = 52;
    }
}